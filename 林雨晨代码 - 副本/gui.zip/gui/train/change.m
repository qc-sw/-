%%��������ͼ����
clear;
Files = dir(fullfile('G:\bishe\New Folder\caries\','*.bmp'));
LengthFiles = length(Files);
for i = 1:LengthFiles;  
    Img = imread(strcat('G:\bishe\New Folder\caries\',Files(i).name));  
    Img=255-Img;
%     figure,imshow(Img);
    imwrite(Img,strcat('G:\bishe\New Folder\caries11\',Files(i).name));
end