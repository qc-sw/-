global Predictor;
addpath('cnn/');
addpath('image processing/');
addpath('GUI/');
mkdir('picture_save');
mkdir('Temporary');
addpath('Temporary');
run GUI.m;
